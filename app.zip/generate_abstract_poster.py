"""
MEDI MIND — RTRP Abstract Poster Generator
Matches the CMR Technical Campus table-based poster format exactly.
"""

from docx import Document
from docx.shared import Pt, Cm, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn, nsdecls
from docx.oxml import parse_xml
import os

def set_cell_shading(cell, color_hex):
    shading = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{color_hex}"/>')
    cell._tc.get_or_add_tcPr().append(shading)

def set_cell_text(cell, text, size=11, bold=False, align=WD_ALIGN_PARAGRAPH.LEFT, font='Times New Roman'):
    cell.text = ''
    p = cell.paragraphs[0]
    p.alignment = align
    run = p.add_run(text)
    run.font.name = font
    run.font.size = Pt(size)
    run.bold = bold
    rPr = run._element.get_or_add_rPr()
    rFonts = parse_xml(f'<w:rFonts {nsdecls("w")} w:ascii="{font}" w:hAnsi="{font}"/>')
    rPr.append(rFonts)

def set_cell_border(cell, top=None, bottom=None, left=None, right=None):
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    tcBorders = parse_xml(f'<w:tcBorders {nsdecls("w")}></w:tcBorders>')
    for side, val in [('top', top), ('bottom', bottom), ('left', left), ('right', right)]:
        if val:
            border = parse_xml(f'<w:{side} {nsdecls("w")} w:val="{val}" w:sz="4" w:space="0" w:color="000000"/>')
            tcBorders.append(border)
    tcPr.append(tcBorders)

def generate():
    doc = Document()

    # Page setup — A4 landscape
    for section in doc.sections:
        section.orientation = 1  # landscape
        section.page_width = Cm(29.7)
        section.page_height = Cm(21.0)
        section.top_margin = Cm(1.0)
        section.bottom_margin = Cm(1.0)
        section.left_margin = Cm(1.0)
        section.right_margin = Cm(1.0)

    style = doc.styles['Normal']
    style.font.name = 'Times New Roman'
    style.font.size = Pt(11)

    # Create main table: 13 rows x 3 columns (matching reference format)
    table = doc.add_table(rows=13, cols=3)
    table.style = 'Table Grid'
    table.alignment = WD_TABLE_ALIGNMENT.CENTER

    # ── ROW 0: Header ──
    cell0 = table.rows[0].cells[0]
    cell0.merge(table.rows[0].cells[1]).merge(table.rows[0].cells[2])
    set_cell_text(cell0,
        "CMR TECHNICAL CAMPUS\n"
        "UGC AUTONOMOUS\n"
        "Accredited by NBA & NAAC with \u2018A\u2019 Grade\n"
        "Approved by AICTE, New Delhi and JNTU Hyderabad\n"
        "Department of Computer Science and Engineering",
        size=12, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    set_cell_shading(cell0, "D9E2F3")

    # ── ROW 1: Title ──
    cell1 = table.rows[1].cells[0]
    cell1.merge(table.rows[1].cells[1]).merge(table.rows[1].cells[2])
    set_cell_text(cell1,
        "TITLE\n"
        "MEDI MIND \u2013 An AI-Powered Unified Healthcare Management Platform",
        size=13, bold=True, align=WD_ALIGN_PARAGRAPH.CENTER)
    set_cell_shading(cell1, "FFF2CC")

    # ── ROW 2: Short Abstract (cols 0-1 merged) + empty col 2 ──
    cell2 = table.rows[2].cells[0]
    cell2.merge(table.rows[2].cells[1])
    set_cell_text(cell2,
        "The modern healthcare ecosystem suffers from critical fragmentation \u2013 patient records are siloed "
        "within individual hospitals, appointment booking remains manual, and intelligent medical assistance "
        "is virtually absent. To address these challenges, this project presents Medi Mind, a full-stack "
        "AI-powered web application that integrates Groq\u2019s Llama 3.3-70B large language model through a "
        "Python Flask backend to deliver real-time, context-aware medical consultation and AI-powered "
        "doctor assignment. The platform features three portals (Patient, Hospital, Admin) with universal "
        "patient identity (PAT-XXXXXXXX), SSE streaming chatbot with voice input across four modes, "
        "AI symptom-to-specialization classification across 15 specialties, downloadable PDF health cards, "
        "Google Maps hospital discovery, and comprehensive audit logging \u2013 all secured by JWT authentication, "
        "bcrypt hashing, and OTP-based password recovery.",
        size=10)

    # ── ROW 3: Detailed Abstract (col 0) + empty cols 1-2 ──
    cell3 = table.rows[3].cells[0]
    set_cell_text(cell3,
        "Medi Mind is built on a Python Flask backend with 40+ REST API endpoints and a MySQL database "
        "with 11 normalized tables. The AI engine uses a dual-model architecture: Llama 3.3-70B-Versatile "
        "for deep medical chatbot consultation with Server-Sent Events (SSE) streaming, and Llama "
        "3.1-8B-Instant for fast symptom classification and auto-generated chat session titles. The "
        "Patient Portal enables universal registration, AI-powered appointment booking where patients "
        "describe symptoms in plain language and the system automatically classifies the specialization "
        "and filters matching doctors from a pool of 20 across 15 specialties, a context-aware chatbot "
        "that injects the patient\u2019s actual medical history into every conversation, voice input via Web "
        "Speech API, complete cross-hospital medical history viewing, and PDF health card generation via "
        "ReportLab. The Hospital Portal provides universal patient access with zero data silos, Chart.js "
        "analytics dashboards, appointment lifecycle management, intelligent word-splitting search, and "
        "medical record creation with structured JSON vitals. The Admin Portal delivers platform-wide "
        "statistics, hospital registry, and comprehensive audit logging with IP tracking.",
        size=10)

    # ── ROW 4: Batch info (cols 1-2 merged) ──
    cell4_right = table.rows[4].cells[1]
    cell4_right.merge(table.rows[4].cells[2])
    set_cell_text(cell4_right,
        "Batch-<XX>:\n"
        "           <Student Name 1>               <Roll No>\n"
        "           <Student Name 2>               <Roll No>\n"
        "           <Student Name 3>               <Roll No>\n"
        "\n\n"
        "FACULTY SUPERVISOR\n"
        "<Guide Name>",
        size=10, bold=False, align=WD_ALIGN_PARAGRAPH.LEFT)

    # ── ROWS 5-9: Existing System points ──
    existing_points = [
        "1. Practo provides doctor discovery and appointment booking but no cross-hospital records, no AI chatbot, no PDF health cards, and no doctor matching.",
        "2. Apollo 24|7 offers teleconsultation but is locked to the Apollo hospital network only \u2013 no universal patient access, no AI classification, no voice input.",
        "3. ABHA (Ayushman Bharat) provides a government digital health ID but is an identity layer only \u2013 no appointments, no AI, no records viewing, no hospital dashboard.",
        "4. Generic HMS (OpenMRS, Bahmni) focuses on internal hospital administration (billing, beds, staff) \u2013 hospital-facing only with no patient portal and no AI features.",
        "5. General-purpose AI chatbots (ChatGPT, Gemini) lack patient-specific context injection, persistent sessions, symptom classification for doctor matching, and voice input.",
    ]
    for i, point in enumerate(existing_points):
        cell = table.rows[5 + i].cells[0]
        set_cell_text(cell, point, size=10)

    # Merge batch info cells for rows 4-10 (right columns)
    for row_idx in range(5, 11):
        c1 = table.rows[row_idx].cells[1]
        c1.merge(table.rows[row_idx].cells[2])

    # ── ROW 10: Empty separator ──
    # Already empty

    # ── ROW 11: Conclusion (col 0 only) ──
    cell11 = table.rows[11].cells[0]
    set_cell_text(cell11,
        "CONCLUSION\n\n"
        "Medi Mind successfully delivers a unified AI-powered healthcare platform connecting patients, hospitals, and administrators.\n"
        "It integrates Groq\u2019s Llama 3.3-70B and 3.1-8B models for real-time medical chatbot and symptom classification.\n"
        "The universal patient identity (PAT-XXXXXXXX) eliminates data silos \u2013 every hospital sees every patient\u2019s complete records.\n"
        "AI-powered symptom-to-specialization classification across 15 specialties automates intelligent doctor matching.\n"
        "Voice input via Web Speech API, PDF health cards, and Google Maps hospital discovery enhance patient accessibility.\n"
        "Secured by JWT, bcrypt, OTP recovery, and audit logging, it provides a production-grade healthcare solution on open-source technologies.",
        size=10, bold=False)
    set_cell_shading(cell11, "E2EFDA")

    # ── ROW 12: Conclusion duplicate / Technologies ──
    cell12 = table.rows[12].cells[0]
    set_cell_text(cell12,
        "TECHNOLOGIES USED\n\n"
        "Backend: Python Flask (40+ endpoints) | Database: MySQL 8.0 (11 tables)\n"
        "AI: Groq \u2013 Llama 3.3-70B (chatbot) + Llama 3.1-8B (classification)\n"
        "Auth: JWT + bcrypt + OTP | PDF: ReportLab | Email: Gmail SMTP\n"
        "Maps: Google Maps JS API + Places API | Voice: Web Speech API\n"
        "Frontend: Vanilla JS SPAs + Apple HIG-inspired design system (apple.css)",
        size=10)

    # ── Save ──
    output = os.path.join(os.path.dirname(__file__), 'MediMind_Abstract_Poster.docx')
    doc.save(output)
    print(f"Saved to: {output}")
    return output

if __name__ == '__main__':
    generate()
